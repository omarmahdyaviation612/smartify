import { Module } from "@nestjs/common";
import { AuthModule } from "../auth/auth.module";
import { AIModule } from "../ai/ai.module";
import { TutorController } from "./tutor.controller";
import { TutorService } from "./tutor.service";

@Module({
  imports: [AuthModule, AIModule],
  controllers: [TutorController],
  providers: [TutorService],
})
export class TutorModule {}
