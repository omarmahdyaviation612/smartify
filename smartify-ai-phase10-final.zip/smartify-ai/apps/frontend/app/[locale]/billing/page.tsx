"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { SmartifyButton, SmartifyContainer } from "@smartify/ui";
import { getBillingCopy } from "@/content/billing";
import { getMarketingCopy } from "@/content/marketing";
import { Navbar } from "@/components/Navbar";
import { useApiClient } from "@/lib/api-client";
import type { Locale } from "@/content/marketing";

interface PricingPlan {
  id: string;
  levelCodeEn: string;
  levelCodeAr: string;
  monthlyPriceEGP: string;
  includedSubjects: number;
  additionalSubjectPriceEGP: string;
}
interface Subscription {
  id: string;
  status: string;
  monthlyTotalEGP: string;
  additionalSubjectsCount: number;
  pricingPlan: PricingPlan;
}

export default function BillingPage() {
  const { locale } = useParams<{ locale: Locale }>();
  const isAr = locale === "ar";
  const copy = getBillingCopy(locale);
  const navCopy = getMarketingCopy(locale);
  const { apiFetch } = useApiClient();

  const [plans, setPlans] = useState<PricingPlan[] | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [extraSubjects, setExtraSubjects] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [notOnboarded, setNotOnboarded] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    Promise.all([apiFetch<PricingPlan[]>("/billing/plans"), apiFetch<Subscription | null>("/billing/subscription")])
      .then(([planData, subData]) => {
        setPlans(planData);
        setSubscription(subData);
        if (planData[0]) setSelectedPlanId(planData[0].id);
      })
      .catch(() => setNotOnboarded(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubscribe() {
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiFetch<{ checkoutUrl: string }>("/billing/checkout", {
        method: "POST",
        body: JSON.stringify({ pricingPlanId: selectedPlanId, additionalSubjectsCount: extraSubjects }),
      });
      window.location.href = res.checkoutUrl;
    } catch (err: any) {
      const msg = err?.message ?? "";
      setError(msg.includes("not configured") || msg.includes("No payment provider") ? copy.notConfigured : copy.genericError);
      setSubmitting(false);
    }
  }

  async function handleCancel() {
    if (!confirm(copy.cancelConfirm)) return;
    try {
      const updated = await apiFetch<Subscription>("/billing/cancel", { method: "POST" });
      setSubscription(updated);
    } catch {
      setError(copy.genericError);
    }
  }

  if (notOnboarded) {
    return (
      <>
        <Navbar locale={locale} copy={navCopy} />
        <main className="flex min-h-[60vh] items-center justify-center text-center text-neutral-600">
          {isAr ? "أكمل التسجيل أولًا." : "Complete onboarding first."}
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar locale={locale} copy={navCopy} />
      <main className="py-12">
        <SmartifyContainer className="mx-auto max-w-2xl">
          <h1 className="text-2xl font-bold text-navy-900">{copy.title}</h1>
          <p className="mt-2 text-neutral-600">{copy.body}</p>

          <div className="mt-8 rounded-sf-lg border border-neutral-200 bg-white p-6">
            <h2 className="mb-3 font-semibold text-navy-900">{copy.currentPlanTitle}</h2>
            {subscription ? (
              <div className="space-y-2 text-sm">
                <p className="text-neutral-700">
                  {isAr ? subscription.pricingPlan.levelCodeAr : subscription.pricingPlan.levelCodeEn} —{" "}
                  {subscription.monthlyTotalEGP} {copy.monthSuffix}
                </p>
                <p className="text-neutral-500">
                  {copy.statusLabel}: <span className="font-medium text-navy-900">{subscription.status}</span>
                </p>
                {subscription.status === "active" && (
                  <SmartifyButton variant="secondary" onClick={handleCancel} className="mt-2">
                    {copy.cancelLabel}
                  </SmartifyButton>
                )}
              </div>
            ) : (
              <p className="text-sm text-neutral-500">{copy.noSubscription}</p>
            )}
          </div>

          {plans && plans.length > 0 && (
            <div className="mt-8">
              <h2 className="mb-4 font-semibold text-navy-900">{copy.choosePlanTitle}</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                {plans.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPlanId(p.id)}
                    className={`rounded-sf-lg border p-5 text-start transition-colors ${
                      selectedPlanId === p.id ? "border-sf-blue-500 bg-[--sf-bg-subtle]" : "border-neutral-200 bg-white"
                    }`}
                  >
                    <p className="font-semibold text-navy-900">{isAr ? p.levelCodeAr : p.levelCodeEn}</p>
                    <p className="mt-1 text-2xl font-bold text-navy-900">
                      {p.monthlyPriceEGP} <span className="text-sm font-normal text-neutral-500">{copy.monthSuffix}</span>
                    </p>
                    <p className="mt-1 text-xs text-neutral-500">{copy.includedSubjects(p.includedSubjects)}</p>
                    <p className="text-xs text-neutral-500">{copy.extraSubjectPrice(p.additionalSubjectPriceEGP)}</p>
                  </button>
                ))}
              </div>

              <label className="mt-6 block">
                <span className="mb-2 block text-sm font-medium text-neutral-700">{copy.additionalSubjectsLabel}</span>
                <input
                  type="number"
                  min={0}
                  max={20}
                  value={extraSubjects}
                  onChange={(e) => setExtraSubjects(Number(e.target.value))}
                  className="w-full rounded-sf border border-neutral-300 px-4 py-2"
                />
              </label>

              {error && <p className="mt-4 text-sm text-error-500">{error}</p>}

              <SmartifyButton variant="ai" className="mt-6 w-full" disabled={submitting || !selectedPlanId} onClick={handleSubscribe}>
                {copy.subscribeLabel}
              </SmartifyButton>
            </div>
          )}
        </SmartifyContainer>
      </main>
    </>
  );
}
